import asyncio
import logging
import os
import signal
import sys
from discord.ext import commands, tasks
import discord
import json
from datetime import datetime
from keep_alive import keep_alive

from bot.config import Config
from bot.commands import setup_commands
from bot.events import setup_events

# تشغيل keep_alive للاستمرارية 24/7
keep_alive()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class DiscordBot(commands.Bot):
    def __init__(self):
        # Configure bot intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.guild_messages = True
        
        super().__init__(
            command_prefix="/",
            intents=intents,
            help_command=None
        )
        
        self.config = Config()
        self.is_shutting_down = False
        
        # تحميل أو إنشاء ملف التقدم
        try:
            with open("progress.json", "r") as f:
                self.progress = json.load(f)
        except:
            self.progress = {}
            
        # رسائل التحفيز للـ 30 يوم
        self.motivations = [
            "🌟 يوم 1: دخلت الغابة السحرية! استعدي للمفاجآت!",
            "💖 يوم 2: قابلت كائن لطيف ساعدك على الاستمرار!",
            "🔥 يوم 3: تحدي النار! لا تخافي، أنتِ قوية!",
            "✨ يوم 4: اكتشفت نهر الأحلام، اسحبي القوة منه!",
            "🌸 يوم 5: تمكّنت من عبور الجسر الغامض، أحسنتِ!",
            "⚡ يوم 6: عاصفة التحديات بدأت، لكنك متألقة!",
            "💎 يوم 7: جمعت جوهرة الطاقة، خطوة للأمام!",
            "🌈 يوم 8: أشعة الشمس تدعمك اليوم، استمري!",
            "💖 يوم 9: صديق صغير يذكرك بقوتك الداخلية!",
            "🔥 يوم 10: نار العزيمة مشتعلة بداخلك!",
            "✨ يوم 11: عثرت على مفتاح الإنجاز، يا بطلة!",
            "🌸 يوم 12: نسيم الأمل يملأ قلبك!",
            "⚡ يوم 13: تسلّقي جبل المثابرة، اقتربي من القمة!",
            "💎 يوم 14: جمعت حجر السعادة، استمري بالرحلة!",
            "🌈 يوم 15: نصف الطريق مكتمل، رائع!",
            "💖 يوم 16: تمكّنتِ من حل لغز الغابة، ممتاز!",
            "🔥 يوم 17: شعلة التصميم بداخلك قوية اليوم!",
            "✨ يوم 18: اكتشفي مغارة الإبداع، استمتعي بالرحلة!",
            "🌸 يوم 19: رياح الانتصار تهب لكِ!",
            "⚡ يوم 20: عاصفة التحديات تخضع لإرادتك!",
            "💎 يوم 21: جمعت جوهرة القوة، أحسنتِ!",
            "🌈 يوم 22: قوس قزح النجاح يظهر أمامك!",
            "💖 يوم 23: صعودك للقمم مستمر، لا تتوقفي!",
            "🔥 يوم 24: نار العزيمة مشتعلة أكثر من أي وقت!",
            "✨ يوم 25: اكتشفت كنز الصبر، ممتاز!",
            "🌸 يوم 26: نسيم الأمل يذكرك بمغامرتك الرائعة!",
            "⚡ يوم 27: اقتربتِ من النهاية، أنتِ قوية!",
            "💎 يوم 28: جمعت حجر الإنجاز، قريب جدًا!",
            "🌈 يوم 29: اليوم الأخير تقريبًا، يا بطلة!",
            "🎉 يوم 30: مبروووك! أنجزتِ التحدي بالكامل مع سباركي! 🏆"
        ]
        
    def save_progress(self):
        """حفظ تقدم المستخدمين"""
        with open("progress.json", "w") as f:
            json.dump(self.progress, f)
    
    async def setup_hook(self):
        """Called when the bot is starting up"""
        logger.info("Setting up bot...")
        
        # Setup commands and events
        await setup_commands(self)
        setup_events(self)
        
        # Setup daily reminder task
        self.daily_reminder.start()
        
        # Sync slash commands (both global and guild-specific)
        try:
            # Global sync
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} global command(s)")
            
            # Guild-specific sync for immediate availability
            for guild in self.guilds:
                try:
                    guild_synced = await self.tree.sync(guild=guild)
                    logger.info(f"Synced {len(guild_synced)} command(s) for guild {guild.name}")
                except Exception as guild_error:
                    logger.error(f"Failed to sync commands for guild {guild.name}: {guild_error}")
                    
        except Exception as e:
            logger.error(f"Failed to sync global commands: {e}")
    
    async def on_ready(self):
        """Called when the bot is ready"""
        logger.info(f"{self.user} has connected to Discord!")
        logger.info(f"Bot is in {len(self.guilds)} guild(s)")
        
        # Set bot activity and ensure it's online
        activity = discord.Activity(
            type=discord.ActivityType.playing,
            name="30-Day Challenge with Sparky! | /help"
        )
        await self.change_presence(activity=activity, status=discord.Status.online)
        logger.info(f"Bot status set to online with activity: {activity.name}")
        
        # Force online status
        await asyncio.sleep(2)
        await self.change_presence(status=discord.Status.online)
        logger.info("Forced bot status to online")
    
    @tasks.loop(hours=24)
    async def daily_reminder(self):
        """تذكير يومي للمستخدمين"""
        now = datetime.now()
        if now.hour == 22:  # الساعة 10 مساءً
            for guild in self.guilds:
                for channel in guild.text_channels:
                    try:
                        await channel.send("⚡ تذكير يا نجوم! اكتبوا /done لتسجيل يومكم في التحدي! 🌟")
                        break
                    except:
                        continue
    
    async def close(self):
        """Graceful shutdown"""
        if not self.is_shutting_down:
            self.is_shutting_down = True
            logger.info("Shutting down bot...")
            # حفظ التقدم قبل الإغلاق
            self.save_progress()
            # إيقاف التذكير اليومي
            if hasattr(self, 'daily_reminder'):
                self.daily_reminder.cancel()
            await super().close()

def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info(f"Received signal {signum}, initiating shutdown...")
    asyncio.create_task(bot.close())

async def main():
    """Main function to run the bot"""
    global bot
    
    # Validate configuration
    if not Config.DISCORD_TOKEN:
        logger.error("DISCORD_TOKEN not found in environment variables!")
        logger.error("Please set your Discord bot token in the DISCORD_TOKEN environment variable.")
        logger.error("Check .env.example for reference.")
        return
    
    # Create bot instance
    bot = DiscordBot()
    
    # Setup signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        logger.info("Starting Discord bot...")
        await bot.start(Config.DISCORD_TOKEN)
    except discord.LoginFailure:
        logger.error("Invalid Discord token provided!")
    except discord.HTTPException as e:
        logger.error(f"HTTP error occurred: {e}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
    finally:
        if not bot.is_closed:
            await bot.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
