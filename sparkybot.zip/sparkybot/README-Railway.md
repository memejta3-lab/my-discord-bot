# Discord Bot - Railway Deployment

هذا البوت جاهز للنشر على Railway.

## الملفات المطلوبة:

- `main.py` - الملف الرئيسي للبوت
- `keep_alive.py` - نظام الحفاظ على البوت نشط
- `bot/` - مجلد أوامر وإعدادات البوت
- `railway_requirements.txt` - المكتبات المطلوبة
- `railway_progress.json` - ملف حفظ التقدم

## خطوات النشر على Railway:

1. **رفع الملفات:**
   - أنشئ مستودع GitHub جديد
   - ارفع جميع الملفات
   - أو ارفعها مباشرة على Railway

2. **إعداد Railway:**
   - اذهب إلى https://railway.app
   - سجل دخول بـ GitHub
   - اضغط "New Project"
   - اختر "Deploy from GitHub repo"

3. **إعداد المتغيرات:**
   - في Railway Dashboard
   - اذهب لـ Variables
   - أضف: `DISCORD_TOKEN` = [التوكن الخاص بك]

4. **أمر التشغيل:**
   - غيّر اسم `railway_requirements.txt` إلى `requirements.txt`
   - غيّر اسم `railway_progress.json` إلى `progress.json`
   - Railway سيشغل `python main.py` تلقائياً

## ملاحظات:

- Railway مجاني لـ 500 ساعة/شهر
- البوت سيعمل 24/7
- احتفظ بنسخة احتياطية من DISCORD_TOKEN

## أوامر البوت:

- `/join` - انضمام للتحدي 30 يوم
- `/done` - تسجيل يوم مكتمل
- `/progress` - عرض التقدم
- `/top` - لوحة المتصدرين
- `/help` - قائمة الأوامر
- `/sync` - إعادة تزامن الأوامر (للمديرين)
