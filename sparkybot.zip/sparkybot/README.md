# Discord Bot

A feature-rich Discord bot built with Python and discord.py that responds to commands and interacts with users.

## Features

- ✅ Slash commands support
- ✅ Prefix commands fallback
- ✅ Message handling and user interaction
- ✅ Error handling and logging
- ✅ Graceful shutdown
- ✅ Bot status indication
- ✅ Rate limit handling
- ✅ Guild join/leave events

## Commands

### Slash Commands
- `/hello` - Say hello to the bot
- `/ping` - Check bot latency
- `/info` - Get bot information
- `/help` - Show available commands
- `/roll [sides]` - Roll a dice (default 100 sides)
- `/choose <options>` - Choose between comma-separated options

### Prefix Commands
- `!hello` - Say hello (prefix fallback)
- `!ping` - Check latency (prefix fallback)

## Setup Instructions

### 1. Create a Discord Application

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application"
3. Give your application a name
4. Go to the "Bot" section
5. Click "Add Bot"
6. Copy the bot token

### 2. Set Up Permissions

In the Discord Developer Portal:
1. Go to the "Bot" section
2. Enable these permissions:
   - Send Messages
   - Use Slash Commands
   - Read Message History
   - Embed Links
   - Add Reactions

### 3. Environment Setup

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and add your bot token:
   ```env
   DISCORD_TOKEN=your_actual_bot_token_here
   