import discord
from discord.ext import commands
from discord import app_commands
import logging
import asyncio
import random

logger = logging.getLogger(__name__)

async def setup_commands(bot):
    """Setup all bot commands"""
    
    # Slash Commands
    @bot.tree.command(name="hello", description="Say hello to the bot")
    async def hello_slash(interaction: discord.Interaction):
        """Slash command to greet users"""
        try:
            embed = discord.Embed(
                title="👋 Hello!",
                description=f"Hello {interaction.user.mention}! I'm {bot.user.name}.",
                color=0x00ff00
            )
            embed.set_footer(text="Thanks for using me!")
            await interaction.response.send_message(embed=embed)
            logger.info(f"Hello command used by {interaction.user}")
        except Exception as e:
            logger.error(f"Error in hello command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="ping", description="Check bot latency")
    async def ping_slash(interaction: discord.Interaction):
        """Check bot latency"""
        try:
            latency = round(bot.latency * 1000)
            embed = discord.Embed(
                title="🏓 Pong!",
                description=f"Bot latency: {latency}ms",
                color=0x0099ff
            )
            await interaction.response.send_message(embed=embed)
            logger.info(f"Ping command used by {interaction.user} - Latency: {latency}ms")
        except Exception as e:
            logger.error(f"Error in ping command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="info", description="Get information about the bot")
    async def info_slash(interaction: discord.Interaction):
        """Display bot information"""
        try:
            embed = discord.Embed(
                title=f"ℹ️ {bot.user.name} Information",
                color=0x7289da
            )
            embed.add_field(name="Servers", value=len(bot.guilds), inline=True)
            embed.add_field(name="Users", value=len(bot.users), inline=True)
            embed.add_field(name="Latency", value=f"{round(bot.latency * 1000)}ms", inline=True)
            embed.add_field(name="Python Version", value="3.8+", inline=True)
            embed.add_field(name="Discord.py Version", value=discord.__version__, inline=True)
            embed.set_thumbnail(url=bot.user.avatar.url if bot.user.avatar else None)
            embed.set_footer(text=f"Bot ID: {bot.user.id}")
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Info command used by {interaction.user}")
        except Exception as e:
            logger.error(f"Error in info command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="help", description="Get help with bot commands")
    async def help_slash(interaction: discord.Interaction):
        """Display help information"""
        try:
            embed = discord.Embed(
                title="📚 Help - Available Commands",
                description="Here are all the commands you can use:",
                color=0x9932cc
            )
            
            commands_list = [
                ("**/hello**", "Say hello to the bot"),
                ("**/ping**", "Check bot latency"),
                ("**/info**", "Get bot information"),
                ("**/help**", "Show this help message"),
                ("**/roll**", "Roll a dice (1-100)"),
                ("**/choose**", "Choose between options"),
                ("**/join**", "Join the 30-day challenge with Sparky!"),
                ("**/done**", "Mark today as completed in your challenge"),
                ("**/progress**", "Check your current challenge progress"),
                ("**/top**", "View the leaderboard of top challengers")
            ]
            
            for name, description in commands_list:
                embed.add_field(name=name, value=description, inline=False)
            
            embed.set_footer(text="Use / to access slash commands")
            await interaction.response.send_message(embed=embed)
            logger.info(f"Help command used by {interaction.user}")
        except Exception as e:
            logger.error(f"Error in help command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="roll", description="Roll a dice (1-100)")
    @app_commands.describe(sides="Number of sides on the dice (default: 100)")
    async def roll_slash(interaction: discord.Interaction, sides: int = 100):
        """Roll a dice with specified sides"""
        try:
            if sides < 1:
                await interaction.response.send_message("Dice must have at least 1 side!", ephemeral=True)
                return
            if sides > 1000:
                await interaction.response.send_message("Dice cannot have more than 1000 sides!", ephemeral=True)
                return
            
            result = random.randint(1, sides)
            embed = discord.Embed(
                title="🎲 Dice Roll",
                description=f"You rolled a **{result}** out of {sides}!",
                color=0xff6b35
            )
            await interaction.response.send_message(embed=embed)
            logger.info(f"Roll command used by {interaction.user} - Result: {result}/{sides}")
        except Exception as e:
            logger.error(f"Error in roll command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="choose", description="Choose between multiple options")
    @app_commands.describe(options="Options separated by commas (e.g., option1, option2, option3)")
    async def choose_slash(interaction: discord.Interaction, options: str):
        """Choose randomly between given options"""
        try:
            choice_list = [option.strip() for option in options.split(',') if option.strip()]
            
            if len(choice_list) < 2:
                await interaction.response.send_message(
                    "Please provide at least 2 options separated by commas!", 
                    ephemeral=True
                )
                return
            
            if len(choice_list) > 20:
                await interaction.response.send_message(
                    "Please provide no more than 20 options!", 
                    ephemeral=True
                )
                return
            
            choice = random.choice(choice_list)
            embed = discord.Embed(
                title="🤔 Choice Made",
                description=f"I choose: **{choice}**",
                color=0x32cd32
            )
            embed.add_field(
                name="Options were:",
                value=", ".join(choice_list),
                inline=False
            )
            await interaction.response.send_message(embed=embed)
            logger.info(f"Choose command used by {interaction.user} - Chose: {choice}")
        except Exception as e:
            logger.error(f"Error in choose command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    # Admin sync command
    @bot.tree.command(name="sync", description="[Admin] Sync bot commands")
    async def sync_slash(interaction: discord.Interaction):
        """Force sync commands (admin only)"""
        try:
            member = interaction.guild.get_member(interaction.user.id) if interaction.guild else None
            if member and member.guild_permissions.administrator:
                # Sync both global and guild
                synced_global = await bot.tree.sync()
                synced_guild = await bot.tree.sync(guild=interaction.guild)
                
                embed = discord.Embed(
                    title="✅ Commands Synced!",
                    description=f"Global: {len(synced_global)} commands\nGuild: {len(synced_guild)} commands\n\nSlash commands should appear now!",
                    color=0x00ff00
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                logger.info(f"Manual sync by {interaction.user} - Global: {len(synced_global)}, Guild: {len(synced_guild)}")
            else:
                await interaction.response.send_message("❌ Admin only command!", ephemeral=True)
        except Exception as e:
            logger.error(f"Error in sync command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    # Challenge Commands
    @bot.tree.command(name="join", description="Join the 30-day challenge with Sparky!")
    async def join_slash(interaction: discord.Interaction):
        """Join the 30-day challenge"""
        try:
            user = str(interaction.user.id)
            if user not in bot.progress:
                bot.progress[user] = 0
                embed = discord.Embed(
                    title="🎯 مرحباً بك في التحدي!",
                    description=f"أهلاً {interaction.user.mention}! انضممتِ للتحدي مع سباركي!\n\n🌟 هدفك: إكمال 30 يوماً من التحدي\n⚡ استخدمي `/done` يومياً لتسجيل تقدمك\n📈 راقبي تقدمك بـ `/progress`",
                    color=0x00ff00
                )
                embed.set_footer(text="حظاً موفقاً في رحلتك! 💫")
                await interaction.response.send_message(embed=embed)
            else:
                embed = discord.Embed(
                    title="⚡ أنتِ مشتركة بالفعل!",
                    description="أنتِ بالفعل مسجلة في التحدي من قبل! استخدمي `/progress` لرؤية تقدمك.",
                    color=0xffa500
                )
                await interaction.response.send_message(embed=embed)
            bot.save_progress()
            logger.info(f"Join command used by {interaction.user}")
        except Exception as e:
            logger.error(f"Error in join command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="done", description="Mark today as completed in your challenge")
    async def done_slash(interaction: discord.Interaction):
        """Mark day as completed"""
        try:
            user = str(interaction.user.id)
            if user not in bot.progress:
                embed = discord.Embed(
                    title="💡 سجلي أولاً!",
                    description="سجلي أولاً باستخدام `/join` للانضمام للتحدي!",
                    color=0xff6b35
                )
                await interaction.response.send_message(embed=embed)
                return
            
            if bot.progress[user] >= 30:
                embed = discord.Embed(
                    title="🎉 تهانينا!",
                    description="لقد أنجزتِ التحدي بالكامل! أنتِ بطلة حقيقية! 🏆",
                    color=0xffd700
                )
                await interaction.response.send_message(embed=embed)
                return
            
            bot.progress[user] += 1
            day = bot.progress[user]
            
            motivation_msg = bot.motivations[day-1] if day <= len(bot.motivations) else "🌸 أحسنتِ! واصلي!"
            
            embed = discord.Embed(
                title="✅ يوم مكتمل!",
                description=f"{interaction.user.mention}\n**اليوم {day}/30**\n\n{motivation_msg}",
                color=0x32cd32
            )
            
            # إضافة بار التقدم
            progress_bar = "█" * (day // 3) + "░" * (10 - (day // 3))
            embed.add_field(
                name="📊 التقدم",
                value=f"`{progress_bar}` {(day/30)*100:.1f}%",
                inline=False
            )
            
            await interaction.response.send_message(embed=embed)
            bot.save_progress()
            logger.info(f"Done command used by {interaction.user} - Day {day}")
        except Exception as e:
            logger.error(f"Error in done command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="progress", description="Check your current challenge progress")
    async def progress_slash(interaction: discord.Interaction):
        """Check challenge progress"""
        try:
            user = str(interaction.user.id)
            if user not in bot.progress:
                embed = discord.Embed(
                    title="💡 سجلي أولاً!",
                    description="سجلي أولاً باستخدام `/join` للانضمام للتحدي!",
                    color=0xff6b35
                )
                await interaction.response.send_message(embed=embed)
                return
            
            day = bot.progress[user]
            percentage = (day/30)*100
            
            embed = discord.Embed(
                title="🔥 تقدمك في التحدي",
                description=f"**{day}/30 يوم** ({percentage:.1f}%)",
                color=0x7289da
            )
            
            # بار التقدم
            progress_bar = "█" * (day // 3) + "░" * (10 - (day // 3))
            embed.add_field(
                name="📊 شريط التقدم",
                value=f"`{progress_bar}`",
                inline=False
            )
            
            # رسالة تحفيزية
            if day == 0:
                motivational = "🌟 ابدئي رحلتك اليوم!"
            elif day < 7:
                motivational = "💪 أسبوع رائع! استمري!"
            elif day < 15:
                motivational = "🔥 أنتِ في منتصف الطريق!"
            elif day < 25:
                motivational = "⚡ تقتربين من النهاية! رائع!"
            elif day < 30:
                motivational = "🏆 أيام قليلة وتكملين! أحسنتِ!"
            else:
                motivational = "🎉 أنجزتِ التحدي بالكامل! مبروك!"
            
            embed.add_field(
                name="💫 رسالة تحفيزية",
                value=motivational,
                inline=False
            )
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Progress command used by {interaction.user} - Day {day}")
        except Exception as e:
            logger.error(f"Error in progress command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    @bot.tree.command(name="top", description="View the leaderboard of top challengers")
    async def top_slash(interaction: discord.Interaction):
        """View leaderboard"""
        try:
            if not bot.progress:
                embed = discord.Embed(
                    title="💡 لم يبدأ أحد التحدي بعد!",
                    description="كوني أول من يبدأ التحدي باستخدام `/join`!",
                    color=0xff6b35
                )
                await interaction.response.send_message(embed=embed)
                return
            
            leaderboard = sorted(bot.progress.items(), key=lambda x: x[1], reverse=True)
            
            embed = discord.Embed(
                title="🏆 لوحة المتصدرين",
                description="أفضل المتحديات في سباركي!",
                color=0xffd700
            )
            
            medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 7
            
            leaderboard_text = ""
            for i, (user_id, days) in enumerate(leaderboard[:10], start=1):
                try:
                    if interaction.guild:
                        member = interaction.guild.get_member(int(user_id))
                        name = member.display_name if member else f"User {user_id[:8]}"
                    else:
                        name = f"User {user_id[:8]}"
                except:
                    name = f"User {user_id[:8]}"
                
                medal = medals[i-1] if i <= len(medals) else "🎖️"
                leaderboard_text += f"{medal} **{i}.** {name} – **{days}** يوم\n"
            
            embed.add_field(
                name="🌟 أبطال التحدي",
                value=leaderboard_text,
                inline=False
            )
            
            # إضافة إحصائيات عامة
            total_users = len(bot.progress)
            completed_users = sum(1 for days in bot.progress.values() if days >= 30)
            embed.add_field(
                name="📊 إحصائيات",
                value=f"👥 المشتركون: {total_users}\n🏆 المكملون: {completed_users}",
                inline=True
            )
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Top command used by {interaction.user}")
        except Exception as e:
            logger.error(f"Error in top command: {e}")
            await interaction.response.send_message("Sorry, something went wrong!", ephemeral=True)
    
    # Prefix Commands (for fallback)
    @bot.command(name="hello")
    async def hello_prefix(ctx):
        """Prefix command to greet users"""
        try:
            embed = discord.Embed(
                title="👋 Hello!",
                description=f"Hello {ctx.author.mention}! Try using `/hello` for the slash command version.",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Error in prefix hello command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    @bot.command(name="ping")
    async def ping_prefix(ctx):
        """Prefix command to check latency"""
        try:
            latency = round(bot.latency * 1000)
            embed = discord.Embed(
                title="🏓 Pong!",
                description=f"Bot latency: {latency}ms\nTry using `/ping` for the slash command version.",
                color=0x0099ff
            )
            await ctx.send(embed=embed)
        except Exception as e:
            logger.error(f"Error in prefix ping command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    # Challenge Prefix Commands
    @bot.command(name="join")
    async def join_prefix(ctx):
        """Join the 30-day challenge (prefix version)"""
        try:
            user = str(ctx.author.id)
            if user not in bot.progress:
                bot.progress[user] = 0
                embed = discord.Embed(
                    title="🎯 مرحباً بك في التحدي!",
                    description=f"أهلاً {ctx.author.mention}! انضممتِ للتحدي مع سباركي!\nاستخدمي `/join` للحصول على تجربة أفضل.",
                    color=0x00ff00
                )
                await ctx.send(embed=embed)
            else:
                await ctx.send("⚡ أنتِ بالفعل مسجلة في التحدي من قبل!")
            bot.save_progress()
        except Exception as e:
            logger.error(f"Error in prefix join command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    @bot.command(name="done")
    async def done_prefix(ctx):
        """Mark day as completed (prefix version)"""
        try:
            user = str(ctx.author.id)
            if user not in bot.progress:
                await ctx.send("💡 سجلي أولاً باستخدام /join")
                return
            if bot.progress[user] >= 30:
                await ctx.send("🎉 لقد أنجزتِ التحدي بالكامل!")
                return
            
            bot.progress[user] += 1
            day = bot.progress[user]
            msg = bot.motivations[day-1] if day <= len(bot.motivations) else "🌸 أحسنتِ! واصلي!"
            await ctx.send(f"{ctx.author.mention} ✅ اليوم {day}/30\n{msg}")
            bot.save_progress()
        except Exception as e:
            logger.error(f"Error in prefix done command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    @bot.command(name="progress")
    async def progress_prefix(ctx):
        """Check progress (prefix version)"""
        try:
            user = str(ctx.author.id)
            if user not in bot.progress:
                await ctx.send("💡 سجلي أولاً باستخدام /join")
                return
            day = bot.progress[user]
            await ctx.send(f"🔥 تقدمك: {day}/30 يوم ({(day/30)*100:.1f}%)")
        except Exception as e:
            logger.error(f"Error in prefix progress command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    @bot.command(name="top")
    async def top_prefix(ctx):
        """View leaderboard (prefix version)"""
        try:
            if not bot.progress:
                await ctx.send("💡 لم يبدأ أحد التحدي بعد!")
                return
            leaderboard = sorted(bot.progress.items(), key=lambda x: x[1], reverse=True)
            msg = "🏆 **لوحة التقدم:**\n"
            for i, (user_id, days) in enumerate(leaderboard[:10], start=1):
                try:
                    member = ctx.guild.get_member(int(user_id))
                    name = member.display_name if member else user_id
                except:
                    name = user_id
                msg += f"{i}. {name} – {days} يوم\n"
            await ctx.send(msg)
        except Exception as e:
            logger.error(f"Error in prefix top command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    @bot.command(name="sync")
    async def sync_prefix(ctx):
        """Force sync commands (admin only)"""
        try:
            if ctx.guild and ctx.author.guild_permissions.administrator:
                synced_global = await bot.tree.sync()
                synced_guild = await bot.tree.sync(guild=ctx.guild)
                await ctx.send(f"✅ **Commands Synced!**\nGlobal: {len(synced_global)} commands\nGuild: {len(synced_guild)} commands\n\nTry `/` now!")
                logger.info(f"Manual prefix sync by {ctx.author} - Global: {len(synced_global)}, Guild: {len(synced_guild)}")
            else:
                await ctx.send("❌ Admin only command!")
        except Exception as e:
            logger.error(f"Error in prefix sync command: {e}")
            await ctx.send("Sorry, something went wrong!")
    
    logger.info("Commands setup completed - including challenge system and sync command")
