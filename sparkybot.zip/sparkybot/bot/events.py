import discord
from discord.ext import commands
from discord import app_commands
import logging
import asyncio

logger = logging.getLogger(__name__)

def setup_events(bot):
    """Setup all bot event handlers"""
    
    @bot.event
    async def on_guild_join(guild):
        """Called when the bot joins a new guild"""
        logger.info(f"Joined new guild: {guild.name} (ID: {guild.id})")
        
        # Sync slash commands for this guild immediately
        try:
            synced = await bot.tree.sync(guild=guild)
            logger.info(f"Synced {len(synced)} commands for new guild {guild.name}")
        except Exception as e:
            logger.error(f"Failed to sync commands for new guild {guild.name}: {e}")
        
        # Send a welcome message to the system channel or first available text channel
        if guild.system_channel and guild.system_channel.permissions_for(guild.me).send_messages:
            channel = guild.system_channel
        else:
            # Find the first text channel the bot can send messages to
            channel = None
            for text_channel in guild.text_channels:
                if text_channel.permissions_for(guild.me).send_messages:
                    channel = text_channel
                    break
        
        if channel:
            try:
                embed = discord.Embed(
                    title="👋 Thanks for adding me!",
                    description=(
                        f"Hello {guild.name}! I'm {bot.user.name}.\n\n"
                        "🔹 Use `/help` to see all available commands\n"
                        "🔹 Use `/hello` to test if I'm working\n"
                        "🔹 Use `/ping` to check my response time\n\n"
                        "Need help? Check out my commands with `/help`!"
                    ),
                    color=0x00ff00
                )
                embed.set_thumbnail(url=bot.user.avatar.url if bot.user.avatar else None)
                embed.set_footer(text="Thanks for using me!")
                await channel.send(embed=embed)
            except Exception as e:
                logger.error(f"Failed to send welcome message in {guild.name}: {e}")
    
    @bot.event
    async def on_guild_remove(guild):
        """Called when the bot is removed from a guild"""
        logger.info(f"Removed from guild: {guild.name} (ID: {guild.id})")
    
    @bot.event
    async def on_command_error(ctx, error):
        """Handle command errors for prefix commands"""
        if isinstance(error, commands.CommandNotFound):
            # Ignore command not found errors
            return
        elif isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You don't have permission to use this command!")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I don't have permission to execute this command!")
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⏰ Command is on cooldown. Try again in {error.retry_after:.2f} seconds.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing required argument: {error.param}")
        else:
            logger.error(f"Unhandled command error in {ctx.command}: {error}")
            await ctx.send("❌ An unexpected error occurred!")
    
    @bot.event
    async def on_app_command_error(interaction, error):
        """Handle slash command errors"""
        try:
            if isinstance(error, app_commands.CommandOnCooldown):
                await interaction.response.send_message(
                    f"⏰ Command is on cooldown. Try again in {error.retry_after:.2f} seconds.",
                    ephemeral=True
                )
            elif isinstance(error, app_commands.MissingPermissions):
                await interaction.response.send_message(
                    "❌ You don't have permission to use this command!",
                    ephemeral=True
                )
            elif isinstance(error, app_commands.BotMissingPermissions):
                await interaction.response.send_message(
                    "❌ I don't have permission to execute this command!",
                    ephemeral=True
                )
            else:
                logger.error(f"Unhandled app command error in {interaction.command}: {error}")
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "❌ An unexpected error occurred!",
                        ephemeral=True
                    )
                else:
                    await interaction.followup.send(
                        "❌ An unexpected error occurred!",
                        ephemeral=True
                    )
        except Exception as e:
            logger.error(f"Error handling app command error: {e}")
    
    @bot.event
    async def on_message(message):
        """Handle incoming messages"""
        # Ignore messages from bots
        if message.author.bot:
            return
        
        # Log mentions
        if bot.user in message.mentions:
            logger.info(f"Bot mentioned by {message.author} in {message.guild.name if message.guild else 'DM'}")
            
            # Respond to direct mentions
            if message.content.strip() == f'<@{bot.user.id}>':
                embed = discord.Embed(
                    title="👋 Hi there!",
                    description="Use `/help` to see what I can do!",
                    color=0x7289da
                )
                try:
                    await message.reply(embed=embed)
                except Exception as e:
                    logger.error(f"Failed to reply to mention: {e}")
        
        # Process commands
        await bot.process_commands(message)
    
    @bot.event
    async def on_disconnect():
        """Called when the bot disconnects"""
        logger.warning("Bot disconnected from Discord")
    
    @bot.event
    async def on_resumed():
        """Called when the bot resumes connection"""
        logger.info("Bot resumed connection to Discord")
    
    @bot.event
    async def on_error(event, *args, **kwargs):
        """Handle general errors"""
        logger.error(f"Error in event {event}: {args}, {kwargs}")
    
    logger.info("Events setup completed")
