import os
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

class Config:
    """Configuration class for the Discord bot"""
    
    # Discord Configuration
    DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
    COMMAND_PREFIX = os.getenv("COMMAND_PREFIX", "/")
    
    # Bot Configuration
    BOT_NAME = os.getenv("BOT_NAME", "Discord Bot")
    BOT_VERSION = "1.0.0"
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    # Feature Flags
    ENABLE_SLASH_COMMANDS = os.getenv("ENABLE_SLASH_COMMANDS", "true").lower() == "true"
    ENABLE_PREFIX_COMMANDS = os.getenv("ENABLE_PREFIX_COMMANDS", "true").lower() == "true"
    
    @classmethod
    def validate(cls):
        """Validate required configuration"""
        errors = []
        
        if not cls.DISCORD_TOKEN:
            errors.append("DISCORD_TOKEN is required")
        
        if errors:
            raise ValueError(f"Configuration errors: {', '.join(errors)}")
        
        return True
