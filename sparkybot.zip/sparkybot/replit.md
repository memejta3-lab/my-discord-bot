# Overview

A feature-rich Discord bot built with Python and discord.py that provides interactive commands and user engagement features. The bot supports both modern slash commands and traditional prefix commands as fallbacks, with comprehensive event handling, logging, and graceful shutdown capabilities. Key features include dice rolling, option selection, bot information commands, and automatic welcome messages for new guilds.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Framework Architecture
- **Core Framework**: Built on discord.py library with commands extension for robust command handling
- **Command System**: Dual command support with slash commands as primary interface and prefix commands (!command) as fallbacks
- **Event-Driven Design**: Modular event handling system for guild joins/leaves and message processing

## Configuration Management
- **Environment-Based Config**: Centralized configuration class using environment variables and .env file support
- **Feature Flags**: Toggle-based system for enabling/disabling slash commands and prefix commands
- **Validation System**: Built-in configuration validation to ensure required tokens and settings are present

## Logging and Monitoring
- **Dual Logging**: File-based logging (bot.log) combined with console output for development and production monitoring
- **Structured Logging**: Timestamped logs with log levels for debugging and operational tracking
- **Error Handling**: Comprehensive try-catch blocks with user-friendly error messages and detailed logging

## Bot Permissions and Intents
- **Minimal Intents**: Configured with message_content, guilds, and guild_messages intents for security
- **Permission Management**: Structured permission requirements for message sending, slash commands, and message history access

## Modular Code Organization
- **Separation of Concerns**: Commands, events, and configuration split into dedicated modules
- **Async Architecture**: Full asynchronous operation for handling multiple Discord interactions simultaneously
- **Graceful Shutdown**: Signal handling for clean bot termination and resource cleanup

# External Dependencies

## Discord Integration
- **discord.py**: Primary library for Discord API interaction and bot functionality
- **Discord Developer Portal**: Bot token management and application configuration

## Python Libraries
- **python-dotenv**: Environment variable management for secure configuration
- **asyncio**: Asynchronous programming support for concurrent operations
- **logging**: Built-in Python logging for operational monitoring

## Development Tools
- **Environment Variables**: DISCORD_TOKEN, COMMAND_PREFIX, BOT_NAME, LOG_LEVEL configuration
- **File System**: Local file logging and configuration file support

## Runtime Environment
- **Python 3.7+**: Required for discord.py compatibility and async/await syntax
- **Network Access**: Required for Discord API communication and real-time event handling